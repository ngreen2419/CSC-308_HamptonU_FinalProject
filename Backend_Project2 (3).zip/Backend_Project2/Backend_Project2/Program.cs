﻿using Microsoft.EntityFrameworkCore;
using NoSQLBackend.Repositories.Course_Content_Service;
using NoSQLBackend.Repositories.Reports_User;
using NoSQLBackend.Repositories.Usage_Logs_Website;
using NoSQLBackend.Services;

var builder = WebApplication.CreateBuilder(args);

var port = Environment.GetEnvironmentVariable("PORT") ?? "8080";
builder.WebHost.UseUrls($"http://0.0.0.0:{port}");

// Register MongoDB Service
builder.Services.AddSingleton<MongoDbService>(sp =>
{
    var conn = builder.Configuration.GetConnectionString("conn");
    return new MongoDbService(conn);
});

// Register PostgreSQL DbContext
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("connsql")));

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Register Repositories for Course Content Service
builder.Services.AddScoped<AssignmentsRepository>();
builder.Services.AddScoped<CoursesRepository>();
builder.Services.AddScoped<ExamsRepository>();
builder.Services.AddScoped<ModulesRepository>();
builder.Services.AddScoped<QuestionsRepository>();

// Register Repositories for User Reports
builder.Services.AddScoped<ReportsRepository>();

// Register Repositories for Website Usage Logs
builder.Services.AddScoped<LogsRepository>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddControllers();

// Register Services
builder.Services.AddScoped<ExamEngineService>();
builder.Services.AddScoped<IntegrityService>();

var app = builder.Build();

app.UseCors("AllowAll");

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();

app.Run();