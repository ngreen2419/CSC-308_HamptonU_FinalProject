﻿using Microsoft.EntityFrameworkCore;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Services;

namespace NoSQLBackend.Repositories.Course_Content_Service
{
    public class ModulesRepository
    {
        private readonly AppDbContext _context;

        public ModulesRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Modules>> GetAllAsync()
        {
            return await _context.Modules.ToListAsync();
        }

        public async Task<Modules?> GetByIdAsync(int id)
        {
            return await _context.Modules.FindAsync(id);
        }

        public async Task CreateAsync(Modules module)
        {
            _context.Modules.Add(module);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var module = await _context.Modules.FindAsync(id);
            if (module != null)
            {
                _context.Modules.Remove(module);
                await _context.SaveChangesAsync();
            }
        }
    }
}