﻿using Microsoft.EntityFrameworkCore;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Services;

namespace NoSQLBackend.Repositories.Course_Content_Service
{
    public class QuestionsRepository
    {
        private readonly AppDbContext _context;

        public QuestionsRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Questions>> GetAllAsync()
        {
            return await _context.Questions.ToListAsync();
        }

        public async Task<Questions?> GetByIdAsync(int id)
        {
            return await _context.Questions.FindAsync(id);
        }

        public async Task CreateAsync(Questions question)
        {
            _context.Questions.Add(question);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var question = await _context.Questions.FindAsync(id);
            if (question != null)
            {
                _context.Questions.Remove(question);
                await _context.SaveChangesAsync();
            }
        }
    }
}