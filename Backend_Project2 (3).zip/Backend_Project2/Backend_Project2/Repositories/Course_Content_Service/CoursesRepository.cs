﻿using Microsoft.EntityFrameworkCore;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Services;

namespace NoSQLBackend.Repositories.Course_Content_Service
{
    public class CoursesRepository
    {
        private readonly AppDbContext _context;

        public CoursesRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Courses>> GetAllAsync()
        {
            return await _context.Courses.ToListAsync();
        }

        public async Task<Courses?> GetByIdAsync(int id)
        {
            return await _context.Courses.FindAsync(id);
        }

        public async Task CreateAsync(Courses course)
        {
            _context.Courses.Add(course);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var course = await _context.Courses.FindAsync(id);
            if (course != null)
            {
                _context.Courses.Remove(course);
                await _context.SaveChangesAsync();
            }
        }
    }
}