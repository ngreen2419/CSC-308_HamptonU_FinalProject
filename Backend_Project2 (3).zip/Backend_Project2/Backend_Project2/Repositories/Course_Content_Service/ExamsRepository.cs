﻿using Microsoft.EntityFrameworkCore;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Services;

namespace NoSQLBackend.Repositories.Course_Content_Service
{
    public class ExamsRepository
    {
        private readonly AppDbContext _context;

        public ExamsRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Exams>> GetAllAsync()
        {
            return await _context.Exams.ToListAsync();
        }

        public async Task<Exams?> GetByIdAsync(int id)
        {
            return await _context.Exams.FindAsync(id);
        }

        public async Task CreateAsync(Exams exam)
        {
            _context.Exams.Add(exam);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var exam = await _context.Exams.FindAsync(id);
            if (exam != null)
            {
                _context.Exams.Remove(exam);
                await _context.SaveChangesAsync();
            }
        }
        internal async Task SubmitExamSession(string sessionId, Dictionary<string, string> answers)
        {
            throw new NotImplementedException();
        }
    }
}