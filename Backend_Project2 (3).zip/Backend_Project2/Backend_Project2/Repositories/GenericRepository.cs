﻿using MongoDB.Driver;

namespace NoSQLBackend.Repositories
{
    public class GenericRepository<T>
    {
        private readonly IMongoCollection<T> _collection;

        public GenericRepository(IMongoDatabase database, string collectionName)
        {
            _collection = database.GetCollection<T>(collectionName);
        }

        public async Task<List<T>> GetAllAsync()
        {
            return await _collection.Find(_ => true).ToListAsync();
        }

        public async Task<T> GetByIdAsync(string id)
        {
            return await _collection
                .Find(Builders<T>.Filter.Eq("Id", id))
                .FirstOrDefaultAsync();
        }

        public async Task CreateAsync(T item)
        {
            await _collection.InsertOneAsync(item);
        }

        public async Task DeleteAsync(string id)
        {
            await _collection.DeleteOneAsync(
                Builders<T>.Filter.Eq("Id", id));
        }
    }
}