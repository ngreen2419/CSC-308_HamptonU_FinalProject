﻿using NoSQLBackend.Services;
using NoSQLBackend.Models.User_Reports;

namespace NoSQLBackend.Repositories.Reports_User
{
    public class ReportsRepository
    {
        public GenericRepository<EngagementReports> Engagement { get; }
        public GenericRepository<IntegrityReports> Integrity { get; }
        public GenericRepository<MaintenanceReports> Maintenance { get; }
        public GenericRepository<SecurityReports> Security { get; }

        public ReportsRepository(MongoDbService db)
        {
            var database = db.GetReportsDatabase();

            Engagement = new GenericRepository<EngagementReports>(database, "Engagement_Reports");
            Integrity = new GenericRepository<IntegrityReports>(database, "Integrity_Reports");
            Maintenance = new GenericRepository<MaintenanceReports>(database, "Maintenance_Reports");
            Security = new GenericRepository<SecurityReports>(database, "Security_Reports");
        }
    }
}
