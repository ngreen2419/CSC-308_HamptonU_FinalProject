﻿using NoSQLBackend.Services;
using NoSQLBackend.Models.Website_Usage_Logs;

namespace NoSQLBackend.Repositories.Usage_Logs_Website
{
    public class LogsRepository
    {
        public GenericRepository<CollectedInformation> CollectedInfo { get; }
        public GenericRepository<StudentLogs> StudentLogs { get; }
        public GenericRepository<ApplicationLogs> ApplicationLogs { get; }

        public LogsRepository(MongoDbService db)
        {
            var database = db.GetLogsDatabase();

            CollectedInfo = new GenericRepository<CollectedInformation>(database, "Collected_Information");
            StudentLogs = new GenericRepository<StudentLogs>(database, "Student_Logs");
            ApplicationLogs = new GenericRepository<ApplicationLogs>(database, "Application_Logs");
        }
    }
}
