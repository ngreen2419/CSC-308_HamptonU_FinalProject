﻿using Microsoft.AspNetCore.Mvc;
using NoSQLBackend.Models.Website_Usage_Logs;
using NoSQLBackend.Repositories.Usage_Logs_Website;

namespace NoSQLBackend.Controllers.Website_Usage_Logs
{
    [ApiController]
    [Route("api/logs")]
    public class LogsController : ControllerBase
    {
        private readonly LogsRepository _repo;

        public LogsController(LogsRepository repo)
        {
            _repo = repo;
        }

        // Collected Info
        [HttpGet("collected")]
        public async Task<IActionResult> GetCollected()
        {
            return Ok(await _repo.CollectedInfo.GetAllAsync());
        }

        [HttpPost("collected")]
        public async Task<IActionResult> PostCollected(CollectedInformation log)
        {
            await _repo.CollectedInfo.CreateAsync(log);
            return Ok(log);
        }

        // Student Logs
        [HttpGet("student")]
        public async Task<IActionResult> GetStudentLogs()
        {
            return Ok(await _repo.StudentLogs.GetAllAsync());
        }

        // Application Logs
        [HttpGet("app")]
        public async Task<IActionResult> GetAppLogs()
        {
            return Ok(await _repo.ApplicationLogs.GetAllAsync());
        }
    }
}