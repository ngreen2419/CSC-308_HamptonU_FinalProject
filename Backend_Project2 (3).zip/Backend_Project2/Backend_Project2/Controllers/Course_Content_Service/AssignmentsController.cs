﻿using Microsoft.AspNetCore.Mvc;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Repositories.Course_Content_Service;

namespace NoSQLBackend.Controllers.Course_Content_Service
{
    [ApiController]
    [Route("api/assignments")]
    public class AssignmentsController : ControllerBase
    {
        private readonly AssignmentsRepository _repo;

        // One constructor
        public AssignmentsController(AssignmentsRepository repo)
        {
            _repo = repo;
        }

        // Get all assignments
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return Ok(await _repo.GetAllAsync());
        }

        // Get assignment by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var assignment = await _repo.GetByIdAsync(id);

            if (assignment == null)
                return NotFound();

            return Ok(assignment);
        }

        // Create assignment
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Assignments assignment)
        {
            await _repo.CreateAsync(assignment);
            return Ok(assignment);
        }

        // Delete assignment
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteAsync(id);
            return NoContent();
        }
    }
}