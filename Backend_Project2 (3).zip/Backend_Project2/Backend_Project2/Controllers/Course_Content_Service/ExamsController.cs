﻿using Microsoft.AspNetCore.Mvc;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Repositories.Course_Content_Service;
using NoSQLBackend.Services;

namespace NoSQLBackend.Controllers.Course_Content_Service
{
    [ApiController]
    [Route("api/exams")]
    public class ExamsController : ControllerBase
    {
        private readonly ExamsRepository _repo;
        private readonly ExamEngineService _engine;

        public ExamsController(ExamsRepository repo, ExamEngineService engine)
        {
            _repo = repo;
            _engine = engine;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
            => Ok(await _repo.GetAllAsync());

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var exam = await _repo.GetByIdAsync(id);
            return exam == null ? NotFound() : Ok(exam);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Exams exam)
        {
            await _repo.CreateAsync(exam);
            return Ok(exam);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteAsync(id);
            return NoContent();
        }

        [HttpPost("{examId}/start")]
        public async Task<IActionResult> StartExam(string examId, [FromQuery] string userId)
        {
            var session = await _engine.StartExam(userId, examId);
            return Ok(session);
        }

        [HttpPost("submit/{sessionId}")]
        public async Task<IActionResult> SubmitExam(string sessionId, [FromBody] Dictionary<string, string> answers)
        {
            var result = await _engine.SubmitExam(sessionId, answers);
            return Ok(result);
        }
    }
}