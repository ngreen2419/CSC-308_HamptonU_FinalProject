﻿using Microsoft.AspNetCore.Mvc;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Repositories.Course_Content_Service;

namespace NoSQLBackend.Controllers.Course_Content_Service
{
    [ApiController]
    [Route("api/questions")]
    public class QuestionsController : ControllerBase
    {
        private readonly QuestionsRepository _repo;

        // One constructor
        public QuestionsController(QuestionsRepository repo)
        {
            _repo = repo;
        }

        // Get all questions
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return Ok(await _repo.GetAllAsync());
        }

        // Get question by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var question = await _repo.GetByIdAsync(id);

            if (question == null)
                return NotFound();

            return Ok(question);
        }

        // Create question
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Questions question)
        {
            await _repo.CreateAsync(question);
            return Ok(question);
        }

        // Delete question
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteAsync(id);
            return NoContent();
        }
    }
}