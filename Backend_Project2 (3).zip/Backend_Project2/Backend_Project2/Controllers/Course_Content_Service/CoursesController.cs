﻿using Microsoft.AspNetCore.Mvc;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Repositories.Course_Content_Service;

namespace NoSQLBackend.Controllers.Course_Content_Service
{
    [ApiController]
    [Route("api/courses")]
    public class CoursesController : ControllerBase
    {
        private readonly CoursesRepository _repo;

        // One constructor
        public CoursesController(CoursesRepository repo)
        {
            _repo = repo;
        }

        // Get all courses
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return Ok(await _repo.GetAllAsync());
        }

        // Get course by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var course = await _repo.GetByIdAsync(id);

            if (course == null)
                return NotFound();

            return Ok(course);
        }

        // Create course
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Courses course)
        {
            await _repo.CreateAsync(course);
            return Ok(course);
        }

        // Delete course
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteAsync(id);
            return NoContent();
        }
    }
}