using Microsoft.AspNetCore.Mvc;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Services;

namespace NoSQLBackend.Controllers.Course_Content_Service
{
    [ApiController]
    [Route("api/users")]
    public class UsersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UsersController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> CreateUser([FromBody] Users user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return Ok(user);
        }

        [HttpGet]
        public async Task<IActionResult> GetUsers()
        {
            return Ok(_context.Users.ToList());
        }
    }
}