﻿using Microsoft.AspNetCore.Mvc;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Repositories.Course_Content_Service;

namespace NoSQLBackend.Controllers.Course_Content_Service
{
    [ApiController]
    [Route("api/modules")]
    public class ModulesController : ControllerBase
    {
        private readonly ModulesRepository _repo;

        public ModulesController(ModulesRepository repo)
        {
            _repo = repo;
        }

        // Get all modules
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return Ok(await _repo.GetAllAsync());
        }

        // Get module by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var module = await _repo.GetByIdAsync(id);

            if (module == null)
                return NotFound();

            return Ok(module);
        }

        // Create module
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Modules module)
        {
            await _repo.CreateAsync(module);
            return Ok(module);
        }

        // Delete module
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteAsync(id);
            return NoContent();
        }
    }
}