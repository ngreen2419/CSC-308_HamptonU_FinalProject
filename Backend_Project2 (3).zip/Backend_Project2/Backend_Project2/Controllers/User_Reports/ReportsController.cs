﻿using Microsoft.AspNetCore.Mvc;
using NoSQLBackend.Repositories.Reports_User;

namespace NoSQLBackend.Controllers.User_Reports
{
    [ApiController]
    [Route("api/reports")]
    public class ReportsController : ControllerBase
    {
        private readonly ReportsRepository _repo;

        public ReportsController(ReportsRepository repo)
        {
            _repo = repo;
        }

        [HttpGet("engagement")]
        public async Task<IActionResult> GetEngagement()
        {
            return Ok(await _repo.Engagement.GetAllAsync());
        }

        [HttpGet("integrity")]
        public async Task<IActionResult> GetIntegrity()
        {
            return Ok(await _repo.Integrity.GetAllAsync());
        }

        [HttpGet("maintenance")]
        public async Task<IActionResult> GetMaintenance()
        {
            return Ok(await _repo.Maintenance.GetAllAsync());
        }

        [HttpGet("security")]
        public async Task<IActionResult> GetSecurity()
        {
            return Ok(await _repo.Security.GetAllAsync());
        }
    }
}
