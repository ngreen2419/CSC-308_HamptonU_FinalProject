﻿using Microsoft.EntityFrameworkCore;
using NoSQLBackend.Models.Course_Content_Service;

namespace NoSQLBackend.Services
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Users> Users { get; set; }
        public DbSet<Courses> Courses { get; set; }
        public DbSet<Students> Students { get; set; }
        public DbSet<Faculty> Faculty { get; set; }
        public DbSet<Staff> Staff { get; set; }
        public DbSet<Assignments> Assignments { get; set; }
        public DbSet<Exams> Exams { get; set; }
        public DbSet<Modules> Modules { get; set; }
        public DbSet<Questions> Questions { get; set; }
        public DbSet<Grades> Grades { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Courses>().ToTable("courses");
            modelBuilder.Entity<Users>().ToTable("users");
            modelBuilder.Entity<Students>().ToTable("students");
            modelBuilder.Entity<Faculty>().ToTable("faculty");
            modelBuilder.Entity<Staff>().ToTable("staff");
            modelBuilder.Entity<Assignments>().ToTable("assignments");
            modelBuilder.Entity<Exams>().ToTable("exams");
            modelBuilder.Entity<Modules>().ToTable("modules");
            modelBuilder.Entity<Questions>().ToTable("questions");
            modelBuilder.Entity<Grades>().ToTable("grades");
            modelBuilder.Entity<Teaches>().ToTable("teaches");
            modelBuilder.Entity<Takes>().ToTable("takes");
            modelBuilder.Entity<LearnsFrom>().ToTable("learns_from");

            modelBuilder.Entity<Users>().HasKey(u => u.User_Id);
            modelBuilder.Entity<Courses>().HasKey(c => c.Course_Id);
            modelBuilder.Entity<Assignments>().HasKey(a => a.Assignment_Id);
            modelBuilder.Entity<Exams>().HasKey(e => e.Exam_Id);
            modelBuilder.Entity<Modules>().HasKey(m => m.Module_Id);
            modelBuilder.Entity<Questions>().HasKey(q => q.Question_Id);
            modelBuilder.Entity<Students>().HasKey(s => s.Student_Id);
            modelBuilder.Entity<Staff>().HasKey(s => s.Staff_Id);
            modelBuilder.Entity<Faculty>().HasKey(f => f.Faculty_Id);

            modelBuilder.Entity<Assignments>()
                .Property(a => a.Assignment_Id)
                .HasColumnName("assignment_id");

            modelBuilder.Entity<Assignments>()
                .Property(a => a.Module_Id)
                .HasColumnName("module_id");

            modelBuilder.Entity<Assignments>()
                .Property(a => a.Title)
                .HasColumnName("title");

            modelBuilder.Entity<Assignments>()
                .Property(a => a.PointsPossible)
                .HasColumnName("points_possible");

            modelBuilder.Entity<Assignments>()
                .Property(a => a.AttemptsAllowed)
                .HasColumnName("attempts_allowed");

            modelBuilder.Entity<Assignments>()
                .Property(a => a.AttemptsMade)
                .HasColumnName("attempts_made");

            modelBuilder.Entity<Assignments>()
                .Property(a => a.AssignmentType)
                .HasColumnName("assignment_type");

            modelBuilder.Entity<Assignments>()
                .Property(a => a.DatePosted)
                .HasColumnName("date_posted");

            modelBuilder.Entity<Assignments>()
                .Property(a => a.DueDate)
                .HasColumnName("due_date");

            modelBuilder.Entity<Assignments>()
                .HasOne(a => a.Module)
                .WithMany()
                .HasForeignKey(a => a.Module_Id);

            modelBuilder.Entity<Exams>()
                .HasOne(e => e.Assignment)
                .WithOne(a => a.Exam)
                .HasForeignKey<Exams>(e => e.Exam_Id);

            modelBuilder.Entity<Questions>()
                .HasOne(q => q.Exam)
                .WithMany(e => e.Questions)
                .HasForeignKey(q => q.Exam_Id);

            modelBuilder.Entity<Modules>()
                .Property(m => m.Module_Id)
                .HasColumnName("module_id");

            modelBuilder.Entity<Modules>()
                .Property(m => m.Course_Id)
                .HasColumnName("course_id");

            modelBuilder.Entity<Modules>()
                .Property(m => m.ModuleName)
                .HasColumnName("module_name");

            modelBuilder.Entity<Assignments>()
                .HasOne(a => a.Module)
                .WithMany()
                .HasForeignKey(a => a.Module_Id);

            modelBuilder.Entity<Questions>()
                .Property(q => q.Question_Id)
                .HasColumnName("question_id");

            modelBuilder.Entity<Questions>()
                .Property(q => q.Exam_Id)
                .HasColumnName("exam_id");

            modelBuilder.Entity<Questions>()
                .Property(q => q.QuestionText)
                .HasColumnName("question_text");

            modelBuilder.Entity<Questions>()
                .Property(q => q.PointsWorth)
                .HasColumnName("points_worth");
            
            modelBuilder.Entity<Questions>()
                .Property(q => q.CorrectAnswer)
                .HasColumnName("correct_answer");

            modelBuilder.Entity<Questions>()
                .HasOne(q => q.Exam)
                .WithMany(e => e.Questions)
                .HasForeignKey(q => q.Exam_Id);
            
            modelBuilder.Entity<Grades>()
                .HasKey(g => new { g.Student_Id, g.Assignment_Id });

            modelBuilder.Entity<Teaches>()
                .HasKey(t => new { t.Faculty_Id, t.Course_Id });

            modelBuilder.Entity<Takes>()
                .HasKey(t => new { t.Student_Id, t.Course_Id });

            modelBuilder.Entity<LearnsFrom>()
                .HasKey(l => new { l.Student_Id, l.Faculty_Id });

            modelBuilder.Entity<Courses>()
                .Property(c => c.Course_Id)
                .HasColumnName("course_id");

            modelBuilder.Entity<Courses>()
                .Property(c => c.CourseName)
                .HasColumnName("course_name");

            modelBuilder.Entity<Courses>()
                .Property(c => c.SectionNumber)
                .HasColumnName("section_number");
            modelBuilder.Entity<Faculty>()
                .HasKey(f => f.Faculty_Id);

            modelBuilder.Entity<Exams>()
                .HasOne(e => e.Assignment)
                .WithOne(a => a.Exam)
                .HasForeignKey<Exams>(e => e.Exam_Id);
            
            modelBuilder.Entity<Exams>()
                .Property(e => e.Exam_Id)
                .HasColumnName("exam_id");

            modelBuilder.Entity<Exams>()
                .Property(e => e.DurationMinutes)
                .HasColumnName("duration");

            modelBuilder.Entity<Exams>()
                .Property(e => e.MaxAttempts)
                .HasColumnName("max_attempts");

            modelBuilder.Entity<Users>()
                .Property(u => u.User_Id)
                .HasColumnName("user_id");

            modelBuilder.Entity<Users>()
                .Property(u => u.Username)
                .HasColumnName("username");

            modelBuilder.Entity<Users>()
                .Property(u => u.Password)
                .HasColumnName("password");

            modelBuilder.Entity<Users>()
                .Property(u => u.Email)
                .HasColumnName("email");

            modelBuilder.Entity<Users>()
                .Property(u => u.Phone_Number)
                .HasColumnName("phone_number");

            modelBuilder.Entity<Users>()
                .OwnsOne(u => u.Name, name =>
                {
                    name.Property(n => n.First_Name).HasColumnName("first_name");
                    name.Property(n => n.Middle_Name).HasColumnName("middle_name");
                    name.Property(n => n.Last_Name).HasColumnName("last_name");
                });

            modelBuilder.Entity<Users>()
                .OwnsOne(u => u.Address, address =>
                {
                    address.Property(a => a.Street).HasColumnName("street");
                    address.Property(a => a.City).HasColumnName("city");
                    address.Property(a => a.State).HasColumnName("state");
                    address.Property(a => a.Zip_Code).HasColumnName("zip_code");
                });

        }
    }
}