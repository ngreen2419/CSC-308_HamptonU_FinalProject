﻿using MongoDB.Driver;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Models.User_Reports;
using NoSQLBackend.Models.Website_Usage_Logs;

namespace NoSQLBackend.Services
{
    public class MongoDbService
    {
        private readonly MongoClient _client;
        private readonly IMongoDatabase _reportsDb;
        private readonly IMongoDatabase _logsDb;

        public MongoDbService(string? connectionString)
        {
            _client = new MongoClient(connectionString);
            _reportsDb = _client.GetDatabase("User_Reports");
            _logsDb = _client.GetDatabase("Website_Usage_Logs");
        }

        public IMongoDatabase GetReportsDatabase() => _reportsDb;
        public IMongoDatabase GetLogsDatabase() => _logsDb;

        // Collections for User_Reports
        public IMongoCollection<EngagementReports> EngagementReports =>
            _reportsDb.GetCollection<EngagementReports>("Engagement_Reports");
        public IMongoCollection<IntegrityReports> IntegrityReports =>
            _reportsDb.GetCollection<IntegrityReports>("Integrity_Reports");
        public IMongoCollection<MaintenanceReports> MaintenanceReports =>
            _reportsDb.GetCollection<MaintenanceReports>("Maintenance_Reports");
        public IMongoCollection<SecurityReports> SecurityReports =>
            _reportsDb.GetCollection<SecurityReports>("Security_Reports");

        // Collections for Website_Usage_Logs
        public IMongoCollection<StudentLogs> StudentLogs =>
            _logsDb.GetCollection<StudentLogs>("Student_Logs");
        public IMongoCollection<ApplicationLogs> ApplicationLogs =>
            _logsDb.GetCollection<ApplicationLogs>("Application_Logs");
        public IMongoCollection<CollectedInformation> CollectedInformation =>
            _logsDb.GetCollection<CollectedInformation>("Collected_Information");
        public IMongoCollection<ExamSessions> ExamSessions =>
            _reportsDb.GetCollection<ExamSessions>("ExamSessions");
    }
}
