﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using NoSQLBackend.Models.Course_Content_Service;
using NoSQLBackend.Services;

namespace NoSQLBackend.Services
{
    public class ExamEngineService
    {
        private readonly MongoDbService _db;
        private readonly AppDbContext appDbContext;

        public ExamEngineService(MongoDbService db, AppDbContext appDbContext)
        {
            _db = db;
            this.appDbContext = appDbContext;
        }

        public async Task<ExamSessions> StartExam(string userId, string examId)
        {
            var exam = await appDbContext.Exams
                .FirstOrDefaultAsync(e => e.Exam_Id.ToString() == examId);

            if (exam == null)
                throw new Exception("Exam not found");

            var attempts = await _db.ExamSessions
                .CountDocumentsAsync(s => s.User_Id == int.Parse(userId) && s.Exam_Id == int.Parse(examId));

            if (exam.MaxAttempts != null && attempts >= exam.MaxAttempts)
                throw new Exception("Max attempts reached");

            var session = new ExamSessions
            {
                User_Id = int.Parse(userId),
                Exam_Id = int.Parse(examId),
                NumAttempt = (int)attempts + 1,
                StartTime = DateTime.UtcNow,
                EndTime = DateTime.UtcNow.AddMinutes((double)(exam.DurationMinutes ?? 0)),
                Submitted = false
            };

            await _db.ExamSessions.InsertOneAsync(session);

            return session;
        }

        public async Task<double> SubmitExam(string sessionId, Dictionary<string, string> answers)
        {
            var session = await _db.ExamSessions
                .Find(s => s.Id == sessionId)
                .FirstOrDefaultAsync();

            if (session == null)
                throw new Exception("Session not found");

            if (DateTime.UtcNow > session.EndTime)
                throw new Exception("Time expired");

            var exam = await appDbContext.Exams
                .Include(e => e.Questions)
                .FirstOrDefaultAsync(e => e.Exam_Id.ToString() == session.Exam_Id.ToString());

            if (exam == null)
                throw new Exception("Exam not found");

            if (exam.Questions == null || exam.Questions.Count == 0)
                throw new Exception("Exam has no questions");

            double correct = 0;

            foreach (var q in exam.Questions)
            {
                var qid = q.Question_Id.ToString();

                if (answers.TryGetValue(qid, out var userAnswer))
                {
                    if (userAnswer == q.CorrectAnswer)
                        correct++;
                }
            }

            double score = (correct / exam.Questions.Count) * 100;

            session.Answers = answers;
            session.PointsScored = score;
            session.Submitted = true;

            await _db.ExamSessions.ReplaceOneAsync(
                s => s.Id == sessionId,
                session
            );

            return score;
        }
    }
}