﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using NoSQLBackend.Models.Course_Content_Service;

namespace NoSQLBackend.Services
{
    public class IntegrityService
    {
        private readonly MongoDbService _mongoDbService;
        public IntegrityService(MongoDbService mongoDbService)
        {
            _mongoDbService = mongoDbService;
        }

        public async Task CheckFastSubmission(ExamSessions session)
        {
            if (session == null)
                throw new ArgumentNullException(nameof(session));

            var duration = session.EndTime - session.StartTime;

            if (duration.TotalSeconds < 30)
            {
                Console.WriteLine(
                    $"Warning: User {session.User_Id} submitted exam {session.Exam_Id} " +
                    $"in {duration.TotalSeconds} seconds (flagged)."
                );

                var filter = Builders<ExamSessions>.Filter.Eq(s => s.Id, session.Id);

                var update = Builders<ExamSessions>.Update
                    .Set(s => s.IsFlagged, true);

                await _mongoDbService.ExamSessions
                    .UpdateOneAsync(filter, update);
            }
        }
    }
}
