﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace NoSQLBackend.Models.Website_Usage_Logs
{
    public class CollectedInformation
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        public int EventId { get; set; }
        public int SessionId { get; set; }
        public string? EventType { get; set; }
        public DateTime TimeOnPlatform { get; set; }
        public string? IPAddress { get; set; }
        public DateTime TimeStamp { get; set; }
        public string? WhereEventHappened { get; set; }
        public string? Severity { get; set; }
    }
}