﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace NoSQLBackend.Models.Website_Usage_Logs
{
    public class ApplicationLogs
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        public int DeviceId { get; set; }
        public string? EventDescription { get; set; }
    }
}