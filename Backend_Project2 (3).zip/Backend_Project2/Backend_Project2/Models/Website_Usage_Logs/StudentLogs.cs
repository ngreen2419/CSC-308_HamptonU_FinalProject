﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace NoSQLBackend.Models.Website_Usage_Logs
{
    public class StudentLogs
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        public int CourseId { get; set; }
        public string? Classification { get; set; }
        public int AssignmentId { get; set; }
    }
}