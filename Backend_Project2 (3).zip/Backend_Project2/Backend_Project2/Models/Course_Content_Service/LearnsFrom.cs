﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class LearnsFrom
    {
        public int Student_Id { get; set; }
        public int Faculty_Id { get; set; }
        public required Students Students { get; set; }
        public required Faculty Faculty { get; set; }
    }
}
