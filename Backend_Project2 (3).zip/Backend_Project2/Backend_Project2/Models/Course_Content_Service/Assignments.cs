﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Assignments
    {
        public int Assignment_Id { get; set; }
        public int Module_Id { get; set; }
        public string? Title { get; set; }
        public int? PointsPossible { get; set; }
        public int? AttemptsAllowed { get; set; }
        public int? AttemptsMade { get; set; }
        public string? AssignmentType { get; set; }
        public DateTime? DatePosted { get; set; }
        public DateTime? DueDate { get; set; }

        public Modules? Module { get; set; }
        public Exams? Exam { get; set; }
    }
}
