﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace NoSQLBackend.Models.Course_Content_Service
{
    public class ExamSessions
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        public int User_Id { get; set; }
        public int Exam_Id { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public bool Submitted { get; set; }
        public int NumAttempt { get; set; }
        public Dictionary<string, string>? Answers { get; set; }
        public double PointsScored { get; set; }
        public bool IsFlagged { get; set; }
    }
}
