﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Grades
    {
        public int Student_Id { get; set; }
        public required Students Students { get; set; }
        public int Assignment_Id { get; set; }
        public required Assignments Assignments { get; set; }
        public int Weight { get; set; }
        public int Grade { get; set; }
        public string? LetterGrade { get; set; }
    }
}
