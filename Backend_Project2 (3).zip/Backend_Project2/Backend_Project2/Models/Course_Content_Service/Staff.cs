﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Staff
    {
        public int Staff_Id { get; set; }
        public string? Position { get; set; }
    }
}
