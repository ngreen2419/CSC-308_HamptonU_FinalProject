﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Students
    {
        public int Student_Id { get; set; }
        public string? Classification { get; set; }
        public string? Major { get; set; }
        public string? Status { get; set; }

        public Users? User { get; set; }
    }
}
