﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Users
    {
        public int User_Id { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
        public string? Email { get; set; }
        public string? Phone_Number { get; set; }
        public Name? Name { get; set; }
        public Address? Address { get; set; }
    }
    public class Name
    {
        public string? First_Name { get; set; }
        public string? Middle_Name { get; set; }
        public string? Last_Name { get; set; }
    }
    public class Address
    {
        public string? Street { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Zip_Code { get; set; }
    }
}
