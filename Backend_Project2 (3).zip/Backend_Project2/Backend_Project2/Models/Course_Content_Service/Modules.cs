﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Modules
    {
        public int Module_Id { get; set; } 
        public string? ModuleName { get; set; }
        public int Course_Id { get; set; }
    }
}