﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Teaches
    {
        public int Faculty_Id { get; set; }
        public int Course_Id { get; set; }
        public required Faculty Faculty { get; set; }
        public required Courses Courses { get; set; }
    }
}
