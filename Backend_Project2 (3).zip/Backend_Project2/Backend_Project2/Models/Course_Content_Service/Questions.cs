﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Questions
    {
        public int Question_Id { get; set; }
        public int Exam_Id { get; set; }
        public Exams? Exam { get; set; }
        public string? QuestionText { get; set; }
        public int PointsWorth { get; set; }
        public string? CorrectAnswer { get; set; }
    }
}