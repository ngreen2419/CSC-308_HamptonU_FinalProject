﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Faculty
    {
        public int Faculty_Id { get; set; }
        public string? Department { get; set; }
        public Users? User { get; set; }
    }
}
