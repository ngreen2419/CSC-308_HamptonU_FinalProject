﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Courses
    {
        public int Course_Id { get; set; } // Primary key
        public string? CourseName { get; set; }
        public string? SectionNumber { get; set; }
    }
}
