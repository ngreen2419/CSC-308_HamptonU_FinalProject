﻿using MongoDB.Bson.Serialization.Attributes;

namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Exams
    {
        public int Exam_Id { get; set; }
        public List<Questions> Questions { get; set; } = new();
        public int? DurationMinutes { get; set; }
        public int? MaxAttempts { get; set; }

        public Assignments? Assignment { get; set; }
    }
}