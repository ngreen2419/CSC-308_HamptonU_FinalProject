﻿namespace NoSQLBackend.Models.Course_Content_Service
{
    public class Takes
    {
        public int Student_Id { get; set; }
        public int Course_Id { get; set; }
        public required Students Students { get; set; }
        public required Courses Courses { get; set; }
    }
}
