﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace NoSQLBackend.Models.User_Reports
{
    public class IntegrityReports
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        public string? Name { get; set; }
        public ClickStreamData ClickStreamData { get; set; } = new();
        public TimestampAnalysis TimestampAnalysis { get; set; } = new();
        public VersionHistoryAnalysis VersionHistoryAnalysis { get; set; } = new();
        public CopyPasteDetection CopyPasteDetection { get; set; } = new();
        public AIUsageDetection AIUsageDetection { get; set; } = new();
        public StyleShift StyleShift { get; set; } = new();
        public CitationErrors CitationErrors { get; set; } = new();

    }

    public class ClickStreamData
    {
        public int TotalClicks { get; set; }
        public int ScrollDepth { get; set; }
    }
    public class TimestampAnalysis
    {
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public double DurationMinutes { get; set; }
    }
    public class VersionHistoryAnalysis
    {
        public int NumberOfEdits { get; set; }
        public bool SuddenLargeChanges { get; set; }
    }
    public class CopyPasteDetection
    {
        public bool Detected { get; set; }
        public double PercentageCopied { get; set; }
    }
    public class AIUsageDetection
    {
        public bool Detected { get; set; }
        public double ConfidenceScore { get; set; }
    }
    public class StyleShift
    {
        public bool Detected { get; set; }
        public string? Notes { get; set; }
    }
    public class CitationErrors
    {
        public int ErrorNum { get; set; }
        public List<string>? CommonErrorTypes { get; set; }
    }
}