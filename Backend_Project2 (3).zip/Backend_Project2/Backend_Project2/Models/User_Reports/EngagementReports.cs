﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace NoSQLBackend.Models.User_Reports
{
    public class EngagementReports
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        public int Age { get; set; }
        public double ConversionRate { get; set; }
        public double AssignmentCompletionRate { get; set; }
        public double AssignmentEngagementRate { get; set; }
        public ActivityBreakdown ActivityBreakdown { get; set; } = new();
        public SessionFrequency SessionFrequency { get; set; } = new();
        public StudentFeedback StudentFeedback { get; set; } = new();
        public ClickAndScrollDepth ClickAndScrollDepth { get; set; } = new();
        public StudentSuccessTopics StudentSuccessTopics { get; set; } = new();
        public StudentStruggleTopics StudentStruggleTopics { get; set; } = new();
        public AssignmentAverages AssignmentAverages { get; set; } = new();
    }
    public class ActivityBreakdown
    {
        public int QuizzesCompleted { get; set; }
        public int AssignmentsCompleted { get; set; }
        public int TestsCompleted { get; set; }
        public int DiscussionPostsCompleted { get; set; }
    }
    public class SessionFrequency
    {
        public int SessionsPerDay { get; set; }
        public int SessionsPerWeek { get; set; }
    }
    public class StudentFeedback
    {
        public int TotalClicks { get; set; }
        public int ScrollDepth { get; set; }
    }
    public class ClickAndScrollDepth
    {
        public int TotalClicks { get; set; }
        public int ScrollDepth { get; set; }
    }
    public class StudentSuccessTopics
    {
        public string? TopSuccess { get; set; }
        public int TopicNum { get; set; }
    }
    public class StudentStruggleTopics
    {
        public string? TopStruggle { get; set; }
        public int TopicNum { get; set; }
    }
    public class AssignmentAverages
    {
        public double Mean { get; set; }
        public int Median { get; set; }
        public int High { get; set; }
        public int UpperQuartile { get; set; }
        public int Low { get; set; }
        public int LowerQuartile { get; set; }
    }
}