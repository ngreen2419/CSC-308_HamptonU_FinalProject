﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace NoSQLBackend.Models.User_Reports
{
    public class MaintenanceReports
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        public string? UserActivity { get; set; }
        public int ActiveUsers { get; set; }
        public string? ErrorCode { get; set; }
        public int Version { get; set; }
        public double ErrorRate { get; set; }
        public int ResponseTimes { get; set; }
        public int RequestID { get; set; }
        public string? ServiceName { get; set; }
    }
}