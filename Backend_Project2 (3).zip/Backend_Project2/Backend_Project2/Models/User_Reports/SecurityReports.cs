﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace NoSQLBackend.Models.User_Reports
{
    public class SecurityReports
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        public string? ThreatType { get; set; }
        public string? RiskRating { get; set; }
    }
}

