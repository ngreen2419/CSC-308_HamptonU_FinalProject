﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace NoSQLBackend.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "courses",
                columns: table => new
                {
                    course_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    course_name = table.Column<string>(type: "text", nullable: true),
                    section_number = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_courses", x => x.course_id);
                });

            migrationBuilder.CreateTable(
                name: "modules",
                columns: table => new
                {
                    module_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    module_name = table.Column<string>(type: "text", nullable: true),
                    course_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_modules", x => x.module_id);
                });

            migrationBuilder.CreateTable(
                name: "staff",
                columns: table => new
                {
                    Staff_Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Position = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_staff", x => x.Staff_Id);
                });

            migrationBuilder.CreateTable(
                name: "users",
                columns: table => new
                {
                    user_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    username = table.Column<string>(type: "text", nullable: true),
                    password = table.Column<string>(type: "text", nullable: true),
                    email = table.Column<string>(type: "text", nullable: true),
                    phone_number = table.Column<string>(type: "text", nullable: true),
                    first_name = table.Column<string>(type: "text", nullable: true),
                    middle_name = table.Column<string>(type: "text", nullable: true),
                    last_name = table.Column<string>(type: "text", nullable: true),
                    street = table.Column<string>(type: "text", nullable: true),
                    city = table.Column<string>(type: "text", nullable: true),
                    state = table.Column<string>(type: "text", nullable: true),
                    zip_code = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_users", x => x.user_id);
                });

            migrationBuilder.CreateTable(
                name: "assignments",
                columns: table => new
                {
                    assignment_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    module_id = table.Column<int>(type: "integer", nullable: false),
                    title = table.Column<string>(type: "text", nullable: true),
                    points_possible = table.Column<int>(type: "integer", nullable: true),
                    attempts_allowed = table.Column<int>(type: "integer", nullable: true),
                    attempts_made = table.Column<int>(type: "integer", nullable: true),
                    assignment_type = table.Column<string>(type: "text", nullable: true),
                    date_posted = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    due_date = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_assignments", x => x.assignment_id);
                    table.ForeignKey(
                        name: "FK_assignments_modules_module_id",
                        column: x => x.module_id,
                        principalTable: "modules",
                        principalColumn: "module_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "faculty",
                columns: table => new
                {
                    Faculty_Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Department = table.Column<string>(type: "text", nullable: true),
                    User_Id = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_faculty", x => x.Faculty_Id);
                    table.ForeignKey(
                        name: "FK_faculty_users_User_Id",
                        column: x => x.User_Id,
                        principalTable: "users",
                        principalColumn: "user_id");
                });

            migrationBuilder.CreateTable(
                name: "students",
                columns: table => new
                {
                    Student_Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Classification = table.Column<string>(type: "text", nullable: true),
                    Major = table.Column<string>(type: "text", nullable: true),
                    Status = table.Column<string>(type: "text", nullable: true),
                    User_Id = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_students", x => x.Student_Id);
                    table.ForeignKey(
                        name: "FK_students_users_User_Id",
                        column: x => x.User_Id,
                        principalTable: "users",
                        principalColumn: "user_id");
                });

            migrationBuilder.CreateTable(
                name: "exams",
                columns: table => new
                {
                    exam_id = table.Column<int>(type: "integer", nullable: false),
                    duration = table.Column<int>(type: "integer", nullable: true),
                    max_attempts = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_exams", x => x.exam_id);
                    table.ForeignKey(
                        name: "FK_exams_assignments_exam_id",
                        column: x => x.exam_id,
                        principalTable: "assignments",
                        principalColumn: "assignment_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "teaches",
                columns: table => new
                {
                    Faculty_Id = table.Column<int>(type: "integer", nullable: false),
                    Course_Id = table.Column<int>(type: "integer", nullable: false),
                    Faculty_Id1 = table.Column<int>(type: "integer", nullable: false),
                    CoursesCourse_Id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_teaches", x => new { x.Faculty_Id, x.Course_Id });
                    table.ForeignKey(
                        name: "FK_teaches_courses_CoursesCourse_Id",
                        column: x => x.CoursesCourse_Id,
                        principalTable: "courses",
                        principalColumn: "course_id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_teaches_faculty_Faculty_Id1",
                        column: x => x.Faculty_Id1,
                        principalTable: "faculty",
                        principalColumn: "Faculty_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "grades",
                columns: table => new
                {
                    Student_Id = table.Column<int>(type: "integer", nullable: false),
                    Assignment_Id = table.Column<int>(type: "integer", nullable: false),
                    StudentsStudent_Id = table.Column<int>(type: "integer", nullable: false),
                    AssignmentsAssignment_Id = table.Column<int>(type: "integer", nullable: false),
                    Weight = table.Column<int>(type: "integer", nullable: false),
                    Grade = table.Column<int>(type: "integer", nullable: false),
                    LetterGrade = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_grades", x => new { x.Student_Id, x.Assignment_Id });
                    table.ForeignKey(
                        name: "FK_grades_assignments_AssignmentsAssignment_Id",
                        column: x => x.AssignmentsAssignment_Id,
                        principalTable: "assignments",
                        principalColumn: "assignment_id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_grades_students_StudentsStudent_Id",
                        column: x => x.StudentsStudent_Id,
                        principalTable: "students",
                        principalColumn: "Student_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "learns_from",
                columns: table => new
                {
                    Student_Id = table.Column<int>(type: "integer", nullable: false),
                    Faculty_Id = table.Column<int>(type: "integer", nullable: false),
                    StudentsStudent_Id = table.Column<int>(type: "integer", nullable: false),
                    Faculty_Id1 = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_learns_from", x => new { x.Student_Id, x.Faculty_Id });
                    table.ForeignKey(
                        name: "FK_learns_from_faculty_Faculty_Id1",
                        column: x => x.Faculty_Id1,
                        principalTable: "faculty",
                        principalColumn: "Faculty_Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_learns_from_students_StudentsStudent_Id",
                        column: x => x.StudentsStudent_Id,
                        principalTable: "students",
                        principalColumn: "Student_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "takes",
                columns: table => new
                {
                    Student_Id = table.Column<int>(type: "integer", nullable: false),
                    Course_Id = table.Column<int>(type: "integer", nullable: false),
                    StudentsStudent_Id = table.Column<int>(type: "integer", nullable: false),
                    CoursesCourse_Id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_takes", x => new { x.Student_Id, x.Course_Id });
                    table.ForeignKey(
                        name: "FK_takes_courses_CoursesCourse_Id",
                        column: x => x.CoursesCourse_Id,
                        principalTable: "courses",
                        principalColumn: "course_id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_takes_students_StudentsStudent_Id",
                        column: x => x.StudentsStudent_Id,
                        principalTable: "students",
                        principalColumn: "Student_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "questions",
                columns: table => new
                {
                    question_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    exam_id = table.Column<int>(type: "integer", nullable: false),
                    question_text = table.Column<string>(type: "text", nullable: true),
                    points_worth = table.Column<int>(type: "integer", nullable: false),
                    correct_answer = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_questions", x => x.question_id);
                    table.ForeignKey(
                        name: "FK_questions_exams_exam_id",
                        column: x => x.exam_id,
                        principalTable: "exams",
                        principalColumn: "exam_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_assignments_module_id",
                table: "assignments",
                column: "module_id");

            migrationBuilder.CreateIndex(
                name: "IX_faculty_User_Id",
                table: "faculty",
                column: "User_Id");

            migrationBuilder.CreateIndex(
                name: "IX_grades_AssignmentsAssignment_Id",
                table: "grades",
                column: "AssignmentsAssignment_Id");

            migrationBuilder.CreateIndex(
                name: "IX_grades_StudentsStudent_Id",
                table: "grades",
                column: "StudentsStudent_Id");

            migrationBuilder.CreateIndex(
                name: "IX_learns_from_Faculty_Id1",
                table: "learns_from",
                column: "Faculty_Id1");

            migrationBuilder.CreateIndex(
                name: "IX_learns_from_StudentsStudent_Id",
                table: "learns_from",
                column: "StudentsStudent_Id");

            migrationBuilder.CreateIndex(
                name: "IX_questions_exam_id",
                table: "questions",
                column: "exam_id");

            migrationBuilder.CreateIndex(
                name: "IX_students_User_Id",
                table: "students",
                column: "User_Id");

            migrationBuilder.CreateIndex(
                name: "IX_takes_CoursesCourse_Id",
                table: "takes",
                column: "CoursesCourse_Id");

            migrationBuilder.CreateIndex(
                name: "IX_takes_StudentsStudent_Id",
                table: "takes",
                column: "StudentsStudent_Id");

            migrationBuilder.CreateIndex(
                name: "IX_teaches_CoursesCourse_Id",
                table: "teaches",
                column: "CoursesCourse_Id");

            migrationBuilder.CreateIndex(
                name: "IX_teaches_Faculty_Id1",
                table: "teaches",
                column: "Faculty_Id1");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "grades");

            migrationBuilder.DropTable(
                name: "learns_from");

            migrationBuilder.DropTable(
                name: "questions");

            migrationBuilder.DropTable(
                name: "staff");

            migrationBuilder.DropTable(
                name: "takes");

            migrationBuilder.DropTable(
                name: "teaches");

            migrationBuilder.DropTable(
                name: "exams");

            migrationBuilder.DropTable(
                name: "students");

            migrationBuilder.DropTable(
                name: "courses");

            migrationBuilder.DropTable(
                name: "faculty");

            migrationBuilder.DropTable(
                name: "assignments");

            migrationBuilder.DropTable(
                name: "users");

            migrationBuilder.DropTable(
                name: "modules");
        }
    }
}
